import { LocalSyncDb } from './localDb';
import { SyncCoordinator } from './coordinator';
import { EntityName, JsonObject, LocalView, ProposedChange } from './types';

/** All screens must read from this repository, not from per-screen Firestore/HTTP/localStorage paths. */
export class UnifiedRepository {
  constructor(private local:LocalSyncDb,private sync:SyncCoordinator) {}
  subscribe(cb:()=>void) {return this.local.subscribe(cb);}
  async all(entity:EntityName):Promise<LocalView[]> {return this.local.listVisible(entity);}
  async put(entity:EntityName,id:string,value:JsonObject):Promise<string> {
    return this.commit([{entity,id,value}]);
  }
  async tombstone(entity:EntityName,id:string):Promise<string> {
    if (['invoices','purchases','vouchers','journalEntries','stockMovements','salesReturns','purchaseReturns','expenses'].includes(entity)) {
      throw new Error('Financial documents must be reversed by a new posting, never deleted');
    }
    return this.commit([{entity,id,value:null}]);
  }
  /** One transaction can include invoice + journal entry + stock movements + voucher. */
  async commit(changes:ProposedChange[], commandId?:string):Promise<string> {
    const cmd=await this.local.enqueue(changes,commandId);
    this.sync.requestSync();
    return cmd.id; // LOCAL SAVED, NOT cloud posted; display pending until ack
  }
}
