import {
  AppliedChange, EntityName, JsonObject, LocalView, ProposedChange, recordKey,
  ServerCursor, ServerEvent, StoredRecord, SyncCommand, toJsonObject, validateChanges
} from './types';

const DB_VERSION = 2;
const RECORDS = 'records', OUTBOX = 'outbox', META = 'meta', RECEIPTS='receipts';
const CURSOR_KEY = 'serverCursor';
const txResult = <T>(r: IDBRequest<T>) => new Promise<T>((resolve, reject) => {
  r.onsuccess = () => resolve(r.result);
  r.onerror = () => reject(r.error ?? new Error('IndexedDB request failed'));
});
const txDone = (tx: IDBTransaction) => new Promise<void>((resolve, reject) => {
  tx.oncomplete = () => resolve();
  tx.onabort = () => reject(tx.error ?? new Error('IndexedDB transaction aborted'));
  tx.onerror = () => reject(tx.error ?? new Error('IndexedDB transaction error'));
});

/** IndexedDB is the device's durable queue; never use localStorage for pending commands. */
export class LocalSyncDb {
  private dbPromise: Promise<IDBDatabase>;
  private listeners = new Set<() => void>();
  private channel: BroadcastChannel | null = null;

  constructor(private workspaceId: string) {
    if (!workspaceId || /[/\u001f]/.test(workspaceId)) throw new Error('Invalid workspaceId');
    const dbName = `lobnan-offline-v1-${workspaceId}`;
    this.dbPromise = new Promise<IDBDatabase>((resolve, reject) => {
      const req = indexedDB.open(dbName, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        const rs = db.objectStoreNames.contains(RECORDS) ? req.transaction!.objectStore(RECORDS) : db.createObjectStore(RECORDS, { keyPath: 'key' });
        if (!rs.indexNames.contains('byEntity')) rs.createIndex('byEntity', 'entity');
        if (!db.objectStoreNames.contains(OUTBOX)) db.createObjectStore(OUTBOX, { keyPath: 'id' });
        if (!db.objectStoreNames.contains(META)) db.createObjectStore(META, { keyPath: 'key' });
        if (!db.objectStoreNames.contains(RECEIPTS)) db.createObjectStore(RECEIPTS,{keyPath:'id'});
      };
      req.onsuccess = () => {
        req.result.onversionchange = () => req.result.close();
        resolve(req.result);
      };
      req.onerror = () => reject(req.error ?? new Error('IndexedDB open failed'));
      req.onblocked = () => console.warn('IndexedDB upgrade blocked by another tab');
    });
    if (typeof BroadcastChannel !== 'undefined') {
      this.channel = new BroadcastChannel(`lobnan-sync-${workspaceId}`);
      this.channel.onmessage = () => this.listeners.forEach(fn => fn());
    }
  }
  private changed(): void {
    this.listeners.forEach(fn => fn());
    this.channel?.postMessage('changed');
  }
  subscribe(callback: () => void): () => void {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }
  async close(): Promise<void> {
    this.channel?.close();
    const db = await this.dbPromise;
    db.close();
  }

  /** Persist command atomically. No UI may claim success until this promise resolves. */
  async enqueue(changes: ProposedChange[], commandId: string = crypto.randomUUID()): Promise<SyncCommand> {
    validateChanges(changes);
    if (!/^[a-zA-Z0-9_-]{8,128}$/.test(commandId)) throw new Error('Invalid commandId');
    const safeChanges = changes.map(c => ({ ...c, value: c.value == null ? null : toJsonObject(c.value) }));
    const db = await this.dbPromise;
    const tx = db.transaction([RECORDS, OUTBOX, RECEIPTS], 'readwrite');
    const done = txDone(tx);
    try {
      const priorReceipt = await txResult(tx.objectStore(RECEIPTS).get(commandId)) as {id:string,requestChanges:ProposedChange[]}|undefined;
      if (priorReceipt) {
        const priorValues = priorReceipt.requestChanges;
        if (JSON.stringify(priorValues) !== JSON.stringify(safeChanges)) throw new Error('Committed operation ID reused with different payload');
        await done;
        return {id:commandId, workspaceId:this.workspaceId, changes:[], createdAt:0, attempts:0,retryAt:0,status:'pending'};
      }
      const [records, outbox] = await Promise.all([
        txResult(tx.objectStore(RECORDS).getAll()) as Promise<StoredRecord[]>,
        txResult(tx.objectStore(OUTBOX).getAll()) as Promise<SyncCommand[]>,
      ]);
      const earlier = outbox.find(command => command.id === commandId);
      if (earlier) {
        if (JSON.stringify(earlier.changes.map(({expectedVersion, ...rest}) => rest)) !== JSON.stringify(safeChanges)) {
          throw new Error('An idempotency ID was reused with a DIFFERENT operation');
        }
        await done;
        return earlier;
      }
      const recordMap = new Map(records.map(r => [r.key, r]));
      // Earlier queued commands increment the expectedVersion once per affected record.
      // Conflicts/rejections stay blocking until a human explicitly resolves them.
      const queued = [...outbox].sort((a, b) => a.createdAt - b.createdAt || a.id.localeCompare(b.id));
      const versioned = safeChanges.map(change => {
        const key = recordKey(change.entity, change.id);
        const prior = queued.filter(op => op.changes.some(c => recordKey(c.entity, c.id) === key)).length;
        return { ...change, expectedVersion: (recordMap.get(key)?.version ?? 0) + prior };
      });
      const cmd: SyncCommand = {
        id: commandId, workspaceId: this.workspaceId, changes: versioned,
        createdAt: Date.now(), status: 'pending', attempts: 0, retryAt: 0
      };
      tx.objectStore(OUTBOX).add(cmd);
      await done;
      this.changed();
      return cmd;
    } catch (error) {
      try { tx.abort(); } catch {}
      await done.catch(() => {});
      throw error;
    }
  }

  async pending(): Promise<SyncCommand[]> {
    const db = await this.dbPromise;
    const tx = db.transaction(OUTBOX, 'readonly');
    const commands = await txResult(tx.objectStore(OUTBOX).getAll()) as SyncCommand[];
    return commands.sort((a, b) => a.createdAt - b.createdAt || a.id.localeCompare(b.id));
  }
  async cursor(): Promise<ServerCursor | null> {
    const db = await this.dbPromise;
    const tx = db.transaction(META, 'readonly');
    const row = await txResult(tx.objectStore(META).get(CURSOR_KEY)) as {key:string,value:ServerCursor}|undefined;
    return row?.value ?? null;
  }
  /** One IndexedDB transaction applies server changes AND advances cursor. Never in reverse order. */
  async applyEvent(event: ServerEvent): Promise<void> {
    const db = await this.dbPromise;
    const tx = db.transaction([RECORDS, OUTBOX, META, RECEIPTS], 'readwrite');
    const done = txDone(tx);
    try {
      const records = tx.objectStore(RECORDS);
      for (const c of event.changes) {
        const key = recordKey(c.entity, c.id);
        const existing = await txResult(records.get(key)) as StoredRecord | undefined;
        if (!existing || existing.version < c.version) {
          records.put({key, entity:c.entity, id:c.id, version:c.version, value:c.value});
        }
      }
      const ownedCommand = await txResult(tx.objectStore(OUTBOX).get(event.commandId));
      tx.objectStore(OUTBOX).delete(event.commandId); // ack is proven by committed event
      if (ownedCommand) {
        const requestChanges=(ownedCommand as SyncCommand).changes.map(({expectedVersion,...proposed})=>proposed);
        tx.objectStore(RECEIPTS).put({id:event.commandId,requestChanges,changes:event.changes});
      }
      const meta = tx.objectStore(META);
      const last = await txResult(meta.get(CURSOR_KEY)) as {key:string,value:ServerCursor}|undefined;
      if (!last || compareCursor(last.value, event.cursor) < 0) {
        meta.put({ key: CURSOR_KEY, value: event.cursor });
      }
      await done;
      this.changed();
    } catch (e) {
      try { tx.abort(); } catch {}
      await done.catch(() => {});
      throw e;
    }
  }
  /** Successful Firestore transaction ack: remove outbox AND update canonical records atomically. */
  async ack(commandId: string, changes: AppliedChange[]): Promise<void> {
    const db = await this.dbPromise;
    const tx = db.transaction([RECORDS, OUTBOX, RECEIPTS], 'readwrite');
    const done = txDone(tx);
    try {
      const records = tx.objectStore(RECORDS);
      for (const c of changes) {
        const key = recordKey(c.entity,c.id);
        const previous = await txResult(records.get(key)) as StoredRecord | undefined;
        if (!previous || previous.version < c.version) {
          records.put({key,entity:c.entity,id:c.id,version:c.version,value:c.value});
        }
      }
      const previousCommand = await txResult(tx.objectStore(OUTBOX).get(commandId)) as SyncCommand | undefined;
      tx.objectStore(OUTBOX).delete(commandId);
      if (previousCommand) {
        const requestChanges=previousCommand.changes.map(({expectedVersion,...proposed})=>proposed);
        tx.objectStore(RECEIPTS).put({id:commandId,requestChanges,changes});
      }
      await done;
      this.changed();
    } catch (e) {
      try { tx.abort(); } catch {}
      await done.catch(() => {});
      throw e;
    }
  }
  async markError(commandId: string, status: SyncCommand['status'], error: string, retryAt = 0): Promise<void> {
    const db = await this.dbPromise;
    const tx = db.transaction(OUTBOX, 'readwrite');
    const done = txDone(tx);
    const store = tx.objectStore(OUTBOX);
    const c = await txResult(store.get(commandId)) as SyncCommand | undefined;
    if (c) store.put({ ...c, status, attempts: c.attempts + 1, error, retryAt });
    await done;
    this.changed();
  }
  /** Single canonical per-record cache + optimistic overlay. All screens should use these selectors. */
  async listVisible(entity: EntityName): Promise<LocalView[]> {
    const db = await this.dbPromise;
    const tx = db.transaction([RECORDS, OUTBOX], 'readonly');
    const [records, pending] = await Promise.all([
      txResult(tx.objectStore(RECORDS).index('byEntity').getAll(entity)) as Promise<StoredRecord[]>,
      txResult(tx.objectStore(OUTBOX).getAll()) as Promise<SyncCommand[]>
    ]);
    const output = new Map<string,LocalView>();
    for (const r of records) if (r.entity === entity) {
      output.set(r.id, {id:r.id, value:r.value, version:r.version, pending:false});
    }
    const sorted = pending.sort((a,b)=>a.createdAt-b.createdAt || a.id.localeCompare(b.id));
    for (const cmd of sorted) for (const c of cmd.changes) if (c.entity === entity) {
      output.set(c.id, {id:c.id,value:c.value,version:c.expectedVersion,pending:true});
    }
    return [...output.values()].filter(row=>row.value!==null);
  }
}
function compareCursor(a: ServerCursor,b: ServerCursor): number {
  if (a.seconds !== b.seconds) return a.seconds - b.seconds;
  if (a.nanoseconds !== b.nanoseconds) return a.nanoseconds - b.nanoseconds;
  return a.eventId.localeCompare(b.eventId);
}
