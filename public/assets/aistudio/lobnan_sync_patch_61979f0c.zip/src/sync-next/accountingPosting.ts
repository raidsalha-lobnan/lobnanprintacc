import { JsonObject, ProposedChange } from './types';

/** Amounts MUST be integer minor units (e.g. agorot, cents), not binary floating-point money. */
export interface JournalLine { accountId: string; debitMinor: number; creditMinor: number }
export interface PostingInput {
  documentEntity: 'invoices' | 'purchases' | 'vouchers' | 'expenses' | 'salesReturns' | 'purchaseReturns';
  documentId: string;
  document: JsonObject;
  journalId: string;
  journalDate: string;
  currency: string;
  lines: JournalLine[];
  movements: ProposedChange[];  // treasury / stock movements with stable IDs and sourceDocumentId
}

/** Pure validation/assembly. Business-specific tax, costing, stock rules MUST be implemented by app's posting engine. */
export function buildAtomicPosting(input: PostingInput): ProposedChange[] {
  if (!input.documentId || !input.journalId || input.documentId===input.journalId) {
    throw new Error('Missing or invalid posting IDs');
  }
  if (!Array.isArray(input.lines) || input.lines.length < 2)throw new Error('Journal needs at least two lines');
  let debit=0,credit=0;
  for (const line of input.lines) {
    if (!line.accountId || !Number.isSafeInteger(line.debitMinor) || !Number.isSafeInteger(line.creditMinor)
      || line.debitMinor<0 || line.creditMinor<0 || (line.debitMinor>0 && line.creditMinor>0)) {
      throw new Error('Invalid journal line');
    }
    debit+=line.debitMinor;credit+=line.creditMinor;
    if (!Number.isSafeInteger(debit)||!Number.isSafeInteger(credit))throw new Error('Money sum overflow');
  }
  if (debit<=0 || debit!==credit)throw new Error(`Unbalanced posting: ${debit} != ${credit}`);
  const doc={...input.document,id:input.documentId};
  const journal:JsonObject={
    id:input.journalId, sourceDocumentId:input.documentId, sourceDocumentType:input.documentEntity,
    currency:input.currency,date:input.journalDate,lines:input.lines.map(l=>({...l}))
  } as JsonObject;
  return [
    {entity:input.documentEntity,id:input.documentId,value:doc},
    {entity:'journalEntries',id:input.journalId,value:journal},
    ...input.movements
  ];
}
