import { db } from '../firebase';
import { FirestoreSyncTransport } from './firestoreTransport';
import { LocalSyncDb } from './localDb';
import { SyncCoordinator } from './coordinator';
import { UnifiedRepository } from './repository';

/**
 * Call once at app root ONLY AFTER migration has established the authoritative workspace.
 * Disabling the old writers is mandatory before enabling this new system in production.
 */
export async function createUnifiedDataLayer(workspaceId:string) {
  const local=new LocalSyncDb(workspaceId);
  const remote=new FirestoreSyncTransport(db,workspaceId);
  const coordinator=new SyncCoordinator(local,remote);
  const repository=new UnifiedRepository(local,coordinator);
  await coordinator.start();
  return {repository,coordinator,local,stop:()=>coordinator.stop()};
}
