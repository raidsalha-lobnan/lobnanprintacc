import { LocalSyncDb } from './localDb';
import { sleep, PermanentSyncError, ServerCursor, SyncCommand, VersionConflict } from './types';

export interface SyncTransport {
  push(command:SyncCommand):Promise<{commandId:string;changes:any[]}>;
  pull(cursor:ServerCursor|null,pageSize?:number):Promise<Array<{commandId:string;changes:any[];cursor:ServerCursor}>>;
  watchLatest(onChanged:()=>void,onError:(error:unknown)=>void):()=>void;
}
export interface SyncState {
  running:boolean; pending:number; conflict:number; lastSuccessAt:number|null; lastError:string|null;
}

/**
 * No swallowed errors and no fake success. A rejected transaction stays on disk.
 * Important: never enable this alongside the legacy sync loop: route ALL writes through this engine.
 */
export class SyncCoordinator {
  private started=false;
  private busy=false;
  private requested=false;
  private timer:ReturnType<typeof setInterval>|null=null;
  private unsubscribe:(()=>void)|null=null;
  private listeners=new Set<(state:SyncState)=>void>();
  private state:SyncState={running:false,pending:0,conflict:0,lastSuccessAt:null,lastError:null};
  private online=()=>typeof navigator==='undefined' || navigator.onLine !== false;
  private onlineHandler=()=>this.requestSync();
  private visibilityHandler=()=>{if(document.visibilityState==='visible')this.requestSync();};

  constructor(private local:LocalSyncDb,private remote:SyncTransport) {}
  onState(fn:(s:SyncState)=>void):()=>void {
    this.listeners.add(fn); fn({...this.state});return ()=>this.listeners.delete(fn);
  }
  private report(partial:Partial<SyncState>) {
    this.state={...this.state,...partial};
    for(const fn of this.listeners)fn({...this.state});
  }
  async start() {
    if(this.started)return;
    this.started=true;
    if(typeof window!=='undefined') {
      window.addEventListener('online',this.onlineHandler);
      document.addEventListener('visibilitychange',this.visibilityHandler);
    }
    // Poll fallback catches missed notification/reconnection; not every 5 seconds.
    this.timer=setInterval(()=>this.requestSync(),120_000);
    this.unsubscribe=this.remote.watchLatest(()=>this.requestSync(),e=>this.report({lastError:String(e)}));
    this.requestSync();
  }
  stop() {
    this.started=false;
    if(this.timer)clearInterval(this.timer);
    this.timer=null;this.unsubscribe?.();this.unsubscribe=null;
    if(typeof window!=='undefined') {
      window.removeEventListener('online',this.onlineHandler);
      document.removeEventListener('visibilitychange',this.visibilityHandler);
    }
  }
  requestSync() {
    if(!this.started)return;
    this.requested=true;
    void this.refreshCounts().catch(e=>this.report({lastError:String(e)}));
    void this.drain();
  }
  private async drain() {
    if(this.busy || !this.online())return;
    this.busy=true;
    this.report({running:true});
    try {
      while(this.requested && this.started && this.online()) {
        this.requested=false;
        await this.pushPending();
        await this.pullAllPages();
      }
      await this.refreshCounts();
      if(this.state.pending===0) this.report({lastSuccessAt:Date.now(),lastError:null});
    } catch (error) {
      this.report({lastError:String(error)});
    } finally {
      this.busy=false;
      this.report({running:false});
      // A change notification may have arrived just before drain exited.
      if(this.requested && this.started)void this.drain();
    }
  }
  private async refreshCounts() {
    const q=await this.local.pending();
    this.report({pending:q.length,conflict:q.filter(c=>c.status!=='pending').length});
  }
  private async pushPending() {
    const cmds=await this.local.pending();
    for(const cmd of cmds) {
      if(!this.started || !this.online())return;
      // FIFO preserves version dependencies. Never skip a conflicted operation and pretend later ones succeeded.
      if(cmd.status!=='pending') {this.report({lastError:`Blocked by ${cmd.status}: ${cmd.id}`});return;}
      if(cmd.retryAt>Date.now())return;
      try {
        const receipt=await this.remote.push(cmd);
        await this.local.ack(receipt.commandId,receipt.changes);
      } catch(e) {
        if(e instanceof VersionConflict) {
          await this.local.markError(cmd.id,'conflict',e.message);
          this.report({lastError:e.message});return;
        }
        if(e instanceof PermanentSyncError || isPermanentFirebaseError(e)) {
          await this.local.markError(cmd.id,'rejected',String(e));
          this.report({lastError:String(e)});return;
        }
        const delay=Math.min(300_000,1000*Math.pow(2,Math.min(cmd.attempts,8)));
        await this.local.markError(cmd.id,'pending',String(e),Date.now()+delay+Math.floor(Math.random()*500));
        this.report({lastError:String(e)});
        return; // do not retry in a tight loop or burn Firebase quota
      }
    }
  }
  private async pullAllPages() {
    let cursor=await this.local.cursor();
    while(this.started && this.online()) {
      const page=await this.remote.pull(cursor,100);
      if(page.length===0)break;
      for(const event of page) {
        await this.local.applyEvent(event); // data + cursor in ONE local transaction
        cursor=event.cursor;
      }
      if(page.length<100)break;
    }
  }
  async waitUntilIdle(timeoutMs=10_000):Promise<void> {
    const start=Date.now();
    while(this.busy) {
      if(Date.now()-start>timeoutMs)throw new Error('Timed out waiting for sync');
      await sleep(25);
    }
  }
}
function isPermanentFirebaseError(error:unknown):boolean {
  const code=String((error as any)?.code??'');
  return code==='permission-denied' || code==='invalid-argument' || code==='failed-precondition';
}
