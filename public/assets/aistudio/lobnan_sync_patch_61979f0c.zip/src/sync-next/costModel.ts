/** Planning estimates, NOT Firebase billing measurements. Use Firebase console for actual usage. */
export interface CostEstimate {minWrites:number;minTransactionReads:number;perReceivingDeviceEventReads:number}
export function estimateCommandCost(entityWrites:number,receivingDevices=1):CostEstimate {
 if(!Number.isSafeInteger(entityWrites)||entityWrites<1||entityWrites>80)throw new Error('Invalid change count');
 if(!Number.isSafeInteger(receivingDevices)||receivingDevices<0)throw new Error('Invalid device count');
 return {
  minWrites:entityWrites+1, // N canonical entity documents + one immutable event document
  minTransactionReads:entityWrites+1, // N existing versions + idempotency receipt probe (attempts/retries may add reads)
  perReceivingDeviceEventReads:receivingDevices // one event doc on catch-up per listening receiving device
 };
}
export function pacificQuotaDay(date:Date=new Date()):string {
 const parts=new Intl.DateTimeFormat('en-US',{
  timeZone:'America/Los_Angeles',year:'numeric',month:'2-digit',day:'2-digit'
 }).formatToParts(date);
 const get=(key:string)=>parts.find(p=>p.type===key)?.value??'';
 return `${get('year')}-${get('month')}-${get('day')}`;
}
