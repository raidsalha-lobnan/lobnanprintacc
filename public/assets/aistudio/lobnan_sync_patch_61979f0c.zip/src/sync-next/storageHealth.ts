/** Browser storage is not an absolute durability guarantee (disk failure, browser eviction, private mode). */
export async function assessLocalStorageHealth():Promise<{
  idbAvailable:boolean; persistent:boolean|null; quotaBytes:number|null; usageBytes:number|null;
}> {
  const idbAvailable=typeof indexedDB!=='undefined';
  if(typeof navigator==='undefined'||!navigator.storage) {
    return {idbAvailable,persistent:null,quotaBytes:null,usageBytes:null};
  }
  const estimate=await navigator.storage.estimate().catch(()=>({quota:undefined,usage:undefined}));
  const persistent=await navigator.storage.persisted().catch(()=>null);
  return {idbAvailable,persistent,quotaBytes:estimate.quota??null,usageBytes:estimate.usage??null};
}
export async function requestPersistentStorage():Promise<boolean> {
  if(typeof navigator==='undefined'||!navigator.storage?.persist)return false;
  return navigator.storage.persist().catch(()=>false);
}
