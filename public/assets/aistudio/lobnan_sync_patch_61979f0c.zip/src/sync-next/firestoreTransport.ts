import {
  collection, doc, documentId, getDocsFromServer, limit, onSnapshot, orderBy, query,
  runTransaction, serverTimestamp, startAfter, Timestamp, type Firestore
} from 'firebase/firestore';
import {
  AppliedChange, CommitReceipt, recordKey, ServerCursor,
  ServerEvent, SyncCommand, VersionConflict
} from './types';

/**
 * NEW namespace, intentionally separate from legacy collections; never mirror legacy writes in parallel.
 * This client-side transaction transport REQUIRES compatible Firestore rules and a migration gate.
 * One atomic operation = N entity writes + 1 immutable event write; no extra per-screen delta writes.
 */
export class FirestoreSyncTransport {
  constructor(private db: Firestore, private workspaceId: string) {
    if (!workspaceId || workspaceId.includes('/')) throw new Error('Invalid workspaceId');
  }
  private records() { return collection(this.db, 'lobnan_sync_workspaces', this.workspaceId, 'records'); }
  private events() { return collection(this.db, 'lobnan_sync_workspaces', this.workspaceId, 'events'); }
  private recId(entity: string,id: string): string { return encodeURIComponent(recordKey(entity as any, id)); }

  async push(command: SyncCommand): Promise<CommitReceipt> {
    if (command.workspaceId !== this.workspaceId) throw new Error('Wrong workspace');
    if (command.changes.length === 0 || command.changes.length > 80) throw new Error('Invalid transaction size');
    const encoded = new TextEncoder().encode(JSON.stringify({workspace:command.workspaceId,changes:command.changes}));
    const digest = await crypto.subtle.digest('SHA-256', encoded);
    const fingerprint = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2,'0')).join('');
    const eventRef = doc(this.events(),command.id);
    const recRefs = command.changes.map(c=>doc(this.records(),this.recId(c.entity,c.id)));
    return runTransaction(this.db,async tx=>{
      // Every read MUST precede any write; callback may be retried by Firestore.
      const already = await tx.get(eventRef);
      if (already.exists()) {
        const existing = already.data();
        if (existing.fingerprint !== fingerprint) throw new Error('IDEMPOTENCY_ID_REUSED_WITH_DIFFERENT_PAYLOAD');
        return {commandId:command.id,changes:existing.changes as AppliedChange[]};
      }
      const existing = await Promise.all(recRefs.map(ref=>tx.get(ref)));
      const applied: AppliedChange[] = [];
      for (let i=0;i<command.changes.length;i++) {
        const proposed = command.changes[i];
        const actual = existing[i].exists() ? Number(existing[i].data()?.version ?? 0) : 0;
        if (actual !== proposed.expectedVersion) {
          throw new VersionConflict(proposed.entity,proposed.id,proposed.expectedVersion,actual);
        }
        applied.push({entity:proposed.entity,id:proposed.id,value:proposed.value,version:actual+1});
      }
      for (let i=0;i<applied.length;i++) {
        const r=applied[i];
        tx.set(recRefs[i],{
          entity:r.entity,id:r.id,version:r.version,
          value:r.value,deleted:r.value === null,updatedAt:serverTimestamp()
        });
      }
      // Immutable event also serves as idempotency receipt; replay of same command consumes no writes.
      tx.set(eventRef,{commandId:command.id,fingerprint,changes:applied,committedAt:serverTimestamp()});
      return {commandId:command.id,changes:applied};
    },{maxAttempts:5});
  }

  async pull(cursor: ServerCursor|null, pageSize=100): Promise<ServerEvent[]> {
    const base = [orderBy('committedAt','asc'),orderBy(documentId(),'asc')];
    const clauses = cursor
      ? [...base,startAfter(new Timestamp(cursor.seconds,cursor.nanoseconds),cursor.eventId),limit(pageSize)]
      : [...base,limit(pageSize)];
    const snapshot = await getDocsFromServer(query(this.events(),...clauses));
    return snapshot.docs.map(s=>{
      const data = s.data();
      const committedAt = data.committedAt as Timestamp | undefined;
      if (!committedAt || typeof committedAt.seconds !== 'number') throw new Error('Unresolved server timestamp');
      return {
        commandId:String(data.commandId),
        changes:data.changes as AppliedChange[],
        cursor:{seconds:committedAt.seconds,nanoseconds:committedAt.nanoseconds,eventId:s.id}
      };
    });
  }

  /** A SINGLE lightweight change signal per active application instance; never limit the catch-up to 100. */
  watchLatest(onChanged:()=>void,onError:(e:unknown)=>void):()=>void {
    const q=query(this.events(),orderBy('committedAt','desc'),limit(1));
    return onSnapshot(q, snapshot=>{
      if (!snapshot.metadata.fromCache) onChanged();
    },onError);
  }
}
