# حزمة نواة المزامنة — برنامج مطبعة لبنان (نسخة 4)

**الحالة: نواة قابلة للدمج، وليست إصلاحًا مثبتًا للبرنامج كاملًا.**

هذه الحزمة تحتوي كود TypeScript جاهزًا ليقوم Google AI Studio **بدمجه واختباره** داخل المشروع الحالي. لم يتم تشغيلها على بيانات Firestore الحقيقية، ولم تُستبدل بها المسارات القديمة، لذا لا تُفعلها في الإنتاج كما هي. موضوع الأمان مستبعد من نطاق المراجعة، لكنه ليس ترخيصًا لفتح قواعد Firestore.

## الملفات

| الملف | الوظيفة |
|---|---|
| `src/sync-next/types.ts` | سجل موحد للكيانات ومعرفات العمليات والنسخ وحالات التعارض |
| `src/sync-next/localDb.ts` | IndexedDB دائم + طابور معاملات + مؤشرات استئناف وACK محلي |
| `src/sync-next/firestoreTransport.ts` | Firestore Transactions مع نسخة السجل، ومعرف طلب ثابت، وحركات ذرية |
| `src/sync-next/coordinator.ts` | إعادة إرسال + سحب صفحات دون الحد 100 + كشف تعارضات وإعادة محاولة |
| `src/sync-next/repository.ts` | API موحدة لجميع الشاشات بدل الحفظ المنفصل |
| `src/sync-next/accountingPosting.ts` | تحقق مبالغ قيود بوحدات نقدية صحيحة وبناء حزمة واحدة |
| `src/sync-next/hooks.ts` | React hooks لقراءة نفس السجلات من جميع الشاشات |
| `src/sync-next/costModel.ts` | نموذج استهلاك نظري لا يدّعي أنه عداد Firebase الرسمي |
| `src/sync-next/storageHealth.ts` | كشف مستوى تخزين الجهاز وطلب الاستدامة عند توافرها |
| `src/sync-next/boot.ts` | التهيئة مرة واحدة باستخدام `db` من `src/firebase.ts` |
| `tests/core.test.ts` | اختبارات وحدة مع خادم محاكى لأهم حالات التزامن |

## ممنوعات قبل الدمج

- **لا تشغّل الطبقة الجديدة بجانب الكتابات القديمة.** ابحث عن جميع استدعاءات `pushDeltaToServer`, `saveDeltaToFirestore`, `saveEntityToFirestore`, `pushFullDatabaseToFirestore`, `postInvoiceDirectlyOnline`, `forceSyncNow`, `syncToFirebase` وأعد توجيهها إلى مسار واحد، ثم أوقف الكتابة القديمة تمامًا بعد نجاح الاختبارات.
- لا تستخدم `localStorage` أو snapshot الموجود داخل `public` أو `.sync_data` كمصدر رسمي بديل داخل كل شاشة.
- لا تدمج بيانات الصناديق تلقائيًا حسب الاسم أو `accountCode`؛ اختلافات الصناديق المثبتة في النسخة الرابعة تتطلب مطابقة بالـ`id` وبحركات الرصيد.
- لا تحذف/تبدل بيانات قديمة أو قيدًا معتمدًا خلال الترحيل.
- لا ترجع نجاحًا بمجرد دخول العملية إلى طابور المزامنة؛ اعرض «محفوظة محليًا — بانتظار اعتماد السحابة».
- لا تولد أرقام الفواتير والسندات الرسمية من قائمة الجهاز؛ يلزم تخصيص مركزي ذري داخل المعاملة نفسها قبل الاعتماد. **تخصيص الرقم الرسمي لم يُنفذ بعد في نواة الكود الحالية**؛ يجب إكماله في الدمج.

## مقتطف API (يلزم تحويل نماذج البيانات إلى JSON والقيم المالية الدقيقة)

```ts
// داخل جذر React بعد اختيار الشركة/المساحة ونجاح مرحلة الترحيل:
import { createUnifiedDataLayer } from './sync-next/boot';
const layer = await createUnifiedDataLayer(companyId); // مرة واحدة فقط

// تسجيل عميل محليًا: يجب أن يظهر في جميع الشاشات عبر useUnifiedCollection
const partyId = crypto.randomUUID();
const operationId = `create-${partyId}`; // معرف ثابت لنقرة الحفظ نفسها
await layer.repository.commit([{ entity:'parties',id:partyId,
  value:{id:partyId,code:'TEMP-'+partyId,name:'عميل تجريبي',type:'customer',phone:'',balance:0}
}],operationId);
// عائد commit هو ID للعملية المحفوظة محليًا، وليس رقم عميل رسميًا ولا إثبات مزامنة.

// قراءة العملاء من أي شاشة
// const {rows,error}=useUnifiedCollection(layer.repository,'parties');
```

**تنبيه:** مثال العميل مبسط، ولا يُستخدم لمنح رقم عميل رسمي. يجب تخصيص أكواد العملاء من جهة مركزية، مع قواعد فريدة حسب الشركة والفرع. يجب أن تكون واجهات الإدخال مرتبطة بمعرف العميل الحقيقي `id`، وليس مجرد `code` نصّي.

## ربط الفواتير والسندات والصندوق

في أنواع المشروع الحالية:
- `Invoice.customerId` يشير إلى `Party.id`.
- `PaymentVoucher.partyId` يشير إلى `Party.id`.
- `PaymentVoucher.referenceInvoiceId` يشير إلى `Invoice.id`.
- `Treasury.id` معرف ثابت؛ `accountCode` رمز حساب وليس هوية الصندوق.
- `Treasury.transactions` مصفوفة مدمجة يجب دراسة ترحيلها إلى `treasuryTransactions` مستقلة بدل إعادة كتابة سجل الصندوق كله عند كل حركة.
- `JournalEntry.referenceId` يجب أن يشير إلى معرف المستند الداخلي، لا رقم الفاتورة الظاهر.
- `StockMovement` يحتاج حقل `sourceDocumentId` ثابتًا في طبقة التخزين بدل الاعتماد على `referenceNumber` النصي وحده.
- `Party.balance`, `Treasury.balance` أرصدة مشتقة، لا تعدلها كل شاشة كمصدر مستقل. احسبها من دفتر معتمد أو materialized view تُحدّث مع العملية الذرية ويُختبر اتساقها.

مثال إدخال مالي مستقل:

```ts
import {buildAtomicPosting} from './sync-next/accountingPosting';
const invoiceId=crypto.randomUUID();
const journalId=`je-${invoiceId}`;
const changes=buildAtomicPosting({
  documentEntity:'invoices',documentId:invoiceId,
  document:{id:invoiceId,invoiceNumber:`TEMP-${invoiceId}`,customerId:'party-uuid',totalMinor:12500},
  journalId,journalDate:'2026-11-06',currency:'ILS',
  lines:[
    {accountId:'cash-account-uuid',debitMinor:12500,creditMinor:0},
    {accountId:'sales-account-uuid',debitMinor:0,creditMinor:12500}
  ],
  movements:[{entity:'treasuryTransactions',id:`tt-${invoiceId}`,
    value:{id:`tt-${invoiceId}`,sourceDocumentId:invoiceId,treasuryId:'treasury-uuid',amountMinor:12500}}]
});
await layer.repository.commit(changes,`post-${invoiceId}`);
```

هذا المثال لا يطبق ضريبة أو تكلفة مخزون أو اشتقاق أرصدة ولا يطابق تلقائيًا واجهة `Invoice` الحالية؛ **يجب على AI Studio إكمال دفتر القيد الفعلي والضرائب وحركات المستودع وفق سياسات البرنامج وتكييف المحوّل إلى `src/types/index.ts`**.

## حماية حصة Firebase Spark

للحزمة الحالية: ترحيل أمر يحتوي N سجلات يتطلب عادة **N+1 كتابات مستندات** (السجلات + حدث واحد)، وقراءات معاملات للتحقق من النسخ/الـACK، بالإضافة إلى قراءات استقبال الأحداث على الأجهزة. هذا تقدير هيكلي وليس احتساب فاتورة دقيقًا؛ قد تزيد القراءات بسبب الاستعلامات، إعادة المحاولة، القواعد والفهارس.

أمثلة أولية دون تكلفة الفهرسة/الأجهزة:
- تعديل عميل واحد: 2 كتابة مستند على الأقل وقراءة تحقق.
- حزمة فاتورة + قيد + سند خزنة + حركتي مخزون: 6 كتابات مستندات على الأقل.
- وضع إشارة استماع واحدة لآخر حدث، وسحب الصفحات عند التغيير فقط.
- وقف polling كل 5 ثوانٍ والتحميل الكامل المتكرر، وعدم إنشاء سجلات ping أو تدقيق سحابي غير ضرورية.

**لا تفترض أن `writeBatch` يقلل عدد كتابات المستندات في Firestore.** قِس الحصة من Firebase Console. حد Spark Standard التقريبي: 50,000 قراءة / 20,000 كتابة / 20,000 حذف يوميًا، 1GiB تخزين و10GiB شهريًا لنقل البيانات الصادرة. يجب التحقق من أن قاعدة البيانات الحالية مؤهلة، فالمشروع يحصل على حصة مجانية لقاعدة واحدة فقط.

سجل الأحداث الكامل قابل للنمو ويستهلك مساحة؛ **ممنوع حذف أو تقليم الأحداث قبل بناء استعادة Snapshot + Cursor وحفظ tombstones والتحقق من أجهزة غابت لفترات طويلة**. قد تتطلب سياسة الأرشفة خادمًا أو تخزينًا بديلًا؛ لا تفعل خدمات مدفوعة دون موافقة.

## ما يتبقى لتنفيذه قبل النشر

1. **ترحيل البيانات القديمة:** إيجاد الـID القانوني لكل صندوق/عميل/فاتورة ومطابقة الأرصدة، واستيراد موثوق دون تشغيل مسارين للكتابة. يجب أن يكون الترحيل تدريجيًا مع أخذ نسخ احتياطية.
2. **تخصيص أرقام رسمية:** معاملات/عدادات مركزية للفواتير والسندات والعملاء، مع الحفاظ على مراجع `id`، وبلا ترقيم نهائي أوفلاين حتى الاعتماد.
3. **منطق الأعمال المحاسبي:** تطبيق قيود اليومية والضريبة وتكلفة المخزون والمعاملات العكسية في حزم لا تقبل التنفيذ الجزئي.
4. **تسوية التعارض:** واجهة لصاحب الصلاحية عندما تتباين `expectedVersion` و`version`، مع خيار مدروس لتصحيح السجلات قبل استئناف الطابور؛ لا تدمج القيود المعتمدة آليًا.
5. **تشغيل متزامن متعدد الألسنة:** leader election أو Web Locks بحيث لا يُنشأ أكثر من listener/worker سحابي لكل مساحة على الجهاز. الحزمة تمنع إعادة التنفيذ عبر ID عمليات لكنها لا توفر انتخاب قائد كاملًا.
6. **التخزين المحلي:** فحص `navigator.storage.persist()` واختباره في Electron/Chrome، واستعادة بيانات عند تلف الملف المحلي أو امتلاء المساحة.
7. **استعادة آخر نسخة موثقة:** الحزمة تفترض وجود تاريخ أحداث كامل. عند تنفيذ event compaction يجب بناء snapshot bootstrap متسق؛ وإلا قد تضيع أحداث بعد انقطاع طويل.
8. **التكامل والأمان التشغيلي:** إنشاء قواعد وصول متوافقة وفهارس Firestore في بيئة تجريبية دون فتح بيانات الإنتاج، واختبار فشل الشبكة، ورفض الأنواع غير المدعومة.

## اختبار الحزمة

في بيئة المشروع التي تحتوي على `@types/node`, `typescript`:

```bash
# شغل من جذر حزمة lobnan_sync_patch:
npx tsc -p tsconfig.check.json
node --test .check/tests/*.test.js
```

هذه الاختبارات تحاكي الخادم والتحقق من تسلسل العمليات؛ **لا تغني عن اختبار IndexedDB أو Firestore Emulator أو تشغيل واجهات البرنامج**.

## روابط التوثيق الرسمي

- Firebase Firestore transactions: https://firebase.google.com/docs/firestore/manage-data/transactions
- Billing: https://firebase.google.com/docs/firestore/pricing
- Cursor-based pagination: https://firebase.google.com/docs/firestore/query-data/query-cursors
